<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
session_start();

$title = "Message History";

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

if ($role === 'admin') {
    $messages = getMessagesForAdmin($pdo);  
} else {
    $messages = getMessagesForUser($pdo, $user_id); 
}

ob_start();
include 'template/message_history.html.php';
$output = ob_get_clean();

include 'template/user_layout.html.php';

