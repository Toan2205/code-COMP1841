
<form method="post">
    <label>Choose Admin:</label>
    <select name="receiver_id" required>
        <?php foreach ($admins as $admin): ?>
            <option value="<?= $admin['id'] ?>">
                <?= htmlspecialchars($admin['email']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <br><br>

    <label>Your Message:</label>
    <textarea name="message" rows="5" cols="50" required></textarea>

    <br>
    <button type="submit">Send Message</button>
</form>
