
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Module</title>
</head>
<body>

<?php if (isset($error)): ?>
    <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php else: ?>
    <table class="module">
        <thead>
            <tr>
                <th>Module name</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($modules as $m): ?>
                <tr>
                    <td><?= htmlspecialchars($m['modulename'], ENT_QUOTES, 'UTF-8') ?> </td>                    
                </tr>   
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

</body>
</html>
