<?php
try{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';
    $modules = allModule($pdo);
    $title = 'Module List';
    $totalQuestion = totalQuestion($pdo);   
    
    ob_start();
    include 'template/module.html.php';
    $output = ob_get_clean();
}catch (PDOException $e){
    $title = 'An error has occured';
    $output = 'Database error:' . $e->getMessage();
}
include 'template/user_layout.html.php';