<?php
session_start();

include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

$title = "Send Message";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login/index.php");
    exit();
}

$admins = getAllAdmins($pdo);

if (!empty($_POST['message']) && !empty($_POST['receiver_id'])) {

    $sender_id = $_SESSION['user_id'];
    $receiver_id = $_POST['receiver_id'];
    $message = $_POST['message'];

    insertMessage($pdo, $sender_id, $receiver_id, $message);

    header("Location: message_history.php");
    exit();
}

ob_start();
include 'template/send_message.html.php';
$output = ob_get_clean();

include 'template/user_layout.html.php';
