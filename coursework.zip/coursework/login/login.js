function showForm(formId) {
    document.querySelectorAll('.login-box').forEach(box => box.classList.remove('active'));
    document.getElementById(formId).classList.add('active');
}
