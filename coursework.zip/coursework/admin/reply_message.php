<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
session_start();

$title = "Reply to User";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login/login_register.php");
    exit;
}
$users = getAllUsers($pdo);

if (isset($_POST['message']) && isset($_POST['receiver_id'])) {

    $sender_id = $_SESSION['user_id'];   
    $receiver_id = $_POST['receiver_id'];
    $message = trim($_POST['message']);

    if ($message !== "") {
        insertMessage($pdo, $sender_id, $receiver_id, $message);
    }

    header("Location: message_history.php");
    exit;
}

ob_start();
include 'template/reply_message.html.php';
$output = ob_get_clean();

include 'template/admin_layout.html.php';
