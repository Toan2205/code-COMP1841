
<?php 
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
try{
    if(isset($_POST['username']) && isset($_POST['email'])){
        updateUser($pdo, $_POST['userid'], $_POST['email'], $_POST['username']);
        header('location: users.php');
   }else {
    $user = getUser($pdo, $_GET['id']);
    $title = 'Edit user';

    ob_start();
    include 'template/editusers.html.php';
    $output = ob_get_clean();
    }
}catch(PDOException $e){
    $title = 'error has occured';
    $output = 'Error editing question: '. $e->getMessage();
}
include 'template/admin_layout.html.php';
