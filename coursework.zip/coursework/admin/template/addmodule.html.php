<form action="" method="post">
    <label for='modulename'>Type module name  here:</label>
    <textarea name="modulename" rows="3" cols="40"></textarea>
    <input type="submit" name="submit" value="Add">
</form>