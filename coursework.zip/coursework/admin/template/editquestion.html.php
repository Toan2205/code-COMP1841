<form action="" method="post">
    <input type="hidden" name="questionid" value="<?=$question['id'];?>">
    
    <label for="title">Edit your question here: </label>
    <textarea name="title" rows="3" cols="40">
        <?=htmlspecialchars($question['title'], ENT_QUOTES, 'UTF-8');?>
    </textarea>

    <label for="users"> Edit user here: </label>
    <select name="users"> 
        <option value="">Select a user</option>
        <?php foreach ($user as $u): ?>
            <option value="<?=htmlspecialchars($u['id'], ENT_QUOTES, 'UTF-8');?>">
                <?=htmlspecialchars($u['username'], ENT_QUOTES,'UTF-8')?>
            </option>
        <?php endforeach ?>
    </select>

    <label for="module"> Edit module here:</label>
    <select name="module"> 
        <option value="">Select a module</option>
        <?php foreach ($module as $m): ?>
            <option value="<?=htmlspecialchars($m['id'], ENT_QUOTES, 'UTF-8');?>">
                <?=htmlspecialchars($m['modulename'], ENT_QUOTES,'UTF-8')?>
            </option>
        <?php endforeach ?>
    </select>

    <input type="submit" name="submit" value="Save">
</form>
