
<form method="post">
    <label>Select User:</label>
    <select name="receiver_id" required>
        <?php foreach ($users as $user): ?>
            <option value="<?= $user['id'] ?>">
                <?= htmlspecialchars($user['email']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <br><br>

    <label>Reply Message:</label>

    <textarea name="message" rows="5" cols="50" required></textarea>
    <br>
    <button type="submit">Send Reply</button>
</form>
