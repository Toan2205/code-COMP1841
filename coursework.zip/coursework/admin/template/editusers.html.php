<form action="" method="post">
    <input type="hidden" name="userid" value="<?=$user['id'];?>">
    
    <label for="username">Edit user name here: </label>
    <textarea name="username" rows="3" cols="40">
        <?=htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8');?>
    </textarea>
    <label for="email"> Edit user email here: </label>
    <textarea name="email" rows="3" cols="40">
        <?=htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8');?>
    </textarea>

    <input type="submit" name="submit" value="Save">
</form>
