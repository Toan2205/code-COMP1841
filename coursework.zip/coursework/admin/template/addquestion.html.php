<form action="" method="post" enctype="multipart/form-data">
    <label for='title'>Type your title here; </label>
    <textarea name="title" rows="3" cols="40"></textarea>
    
    <input type="file" name="fileToUpload">

    <select name="users">
        <option value="">Select an user</option>
        <?php foreach ($user as $u): ?>
            <option value="<?=htmlspecialchars($u['id'], ENT_QUOTES, 'UTF-8');?>">
                <?=htmlspecialchars($u['username'], ENT_QUOTES, 'UTF-8')?>
            </option>
        <?php endforeach ?>

    </select>
     <select name="module">
        <option value="">Select an module</option>
        <?php foreach ($module as $m): ?>
            <option value="<?=htmlspecialchars($m['id'], ENT_QUOTES, 'UTF-8');?>">
            <?=htmlspecialchars($m['modulename'], ENT_QUOTES,'UTF-8')?>
            </option>
        <?php endforeach ?>
    </select>
    <input type="submit" name="submit" value="Add">
</form>