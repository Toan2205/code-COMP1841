<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href = "question.css">
    <title><?=$title?></title>
</head>
<body>
    <header><h1>Well come to student service (Admin area)</h1></header>
    <nav>
        <ul>
            <li><a href="admin_page.php">Home</a></li>
            <li><a href="question.php">Question List</a></li>
            <li><a href="addquestion.php">Add a new question</a></li>
            <li><a href="users.php"> Users List</a></li>
            <li><a href="addusers.php"> Add new user</a></li>
            <li><a href="module.php"> Module List </a></li> 
            <li><a href="addmodule.php"> Add new module</a></li> 
            <li><a href="message_history.php">Message History</a></li>
            <li><a href="reply_message.php">Reply Message</a></li>
            <li><a href="../login/logout.php">Logout</a></li>
        </ul>
    </nav>
    <main>
        <?=$output?>
    </main>
    <footer>&copy; IJDB 2023</footer>
</body>
</html>