<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Questions</title>
</head>
<body>

<?php if (isset($error)): ?>
    <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php else: ?>
    <table class="question">
        <thead>
            <tr>
                <th>Question Title</th>
                <th> Module </th>
                <th>Date</th>
                <th>Image</th>
                <th> Edit question </th>
                <th> Delete question</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($questions as $question): ?>
                <tr>
                    <td><?= htmlspecialchars($question['title'], ENT_QUOTES, 'UTF-8') ?>
                    (by <a href="mailto:<?htmlspecialchars($question['email'], ENT_QUOTES, 'UTF-8');?>">
                        <?=htmlspecialchars($question['username'], ENT_QUOTES, 'UTF-8');?></a>)
                    </td>
                    <td> <?= htmlspecialchars($question['modulename'], ENT_QUOTES, 'UTF-8') ?> </td>
                    <td>    
                        <?php
                            $display_date = date("D d M Y", strtotime($question['questiondate']));
                            echo htmlspecialchars($display_date, ENT_QUOTES, 'UTF-8');
                        ?>
                    </td>
                    <td><img height="100px" width="100px" src="../images/<?=htmlspecialchars($question['image'], ENT_QUOTES, 'UTF-8'); ?>"/></td>
                    <td> <a href="editquestion.php?id=<?=$question['id']?>"> Edit </a></td>
                    <td> 
                        <form action="deletequestion.php" method="post">
                            <input type="hidden" name="id" value="<?=$question['id']?>"> 
                            <input type="submit" value="Delete">
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

</body>
</html>
