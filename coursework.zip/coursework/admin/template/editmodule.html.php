<form action="" method="post">
    <input type="hidden" name="moduleid" value="<?=$module['id'];?>">
    
    <label for="modulename">Edit module name here: </label>
    <textarea name="modulename" rows="3" cols="40">
        <?=htmlspecialchars($module['modulename'], ENT_QUOTES, 'UTF-8');?>
    </textarea>
    <input type="submit" name="submit" value="Save">
</form>
