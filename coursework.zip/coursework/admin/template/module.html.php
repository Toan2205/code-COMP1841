
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Module</title>
</head>
<body>

<?php if (isset($error)): ?>
    <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
<?php else: ?>
    <table class="module">
        <thead>
            <tr>
                <th>Module name</th>
                <th> Edit module </th>
                <th> Delete module</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($modules as $m): ?>
                <tr>
                    <td><?= htmlspecialchars($m['modulename'], ENT_QUOTES, 'UTF-8') ?> </td>                    
                    <td> <a href="editmodule.php?id=<?=$m['id']?>"> Edit </a></td>
                    <td> 
                        <form action="deletemodule.php" method="post">
                            <input type="hidden" name="id" value="<?=$m['id']?>"> 
                            <input type="submit" value="Delete">
                        </form>
                    </td>
                </tr>   
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

</body>
</html>
