<form action="" method="post">
    <label for='username'>Type user name  here:</label>
    <textarea name="username" rows="3" cols="40"></textarea>
    <label for='email'>Type user email  here: </label>
    <textarea name="email" rows="3" cols="40"></textarea>
    <input type="submit" name="submit" value="Add">
</form>