
<table border="1" cellpadding="8" cellspacing="0">
    <thead>
        <tr>
            <th>Sender</th>
            <th>Receiver</th>
            <th>Message</th>
            <th>Sent At</th>
        </tr>
    </thead>

    <tbody>
    <?php if (!empty($messages)): ?>
        <?php foreach ($messages as $msg): ?>
            <tr>
                <td><?= htmlspecialchars($msg['sender_email']) ?></td>
                <td><?= htmlspecialchars($msg['receiver_email']) ?></td>
                <td><?= nl2br(htmlspecialchars($msg['message'])) ?></td>
                <td><?= htmlspecialchars($msg['sent_at']) ?></td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="4">No messages available.</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
