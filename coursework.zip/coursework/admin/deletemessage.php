<?php 
try{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';
    deleteMessage($pdo, $_POST['id']);
    header ('location: message_history.php');
}catch (PDOException $e){
        $title = 'An error has occured';
        $output = 'Database error:'. $e->getMessage();
    }
include 'template/admin_layout.html.php';
?>