<?php
if(isset($_POST['title'])){
    try{
        include '../includes/DatabaseConnection.php';
        include '../includes/DatabaseFunctions.php';
        insertQuestion($pdo, $_POST['title'], $_POST['users'], $_POST['module'] );
        header('location: question.php');
    }catch (PDOException $e){
        $title = 'An error has occured';
        $output = 'Database error:' . $e->getMessage();
    }
}else{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';
    $title = 'Add a new question';
    $user = allUser($pdo);
    $module = allModule($pdo);
    ob_start();
    include 'template/addquestion.html.php';
    $output = ob_get_clean();
}
include 'template/layout.html.php';