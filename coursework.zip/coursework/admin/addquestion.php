<?php
if (isset($_POST['title'])) {
    try {
        include '../includes/DatabaseConnection.php';
        include '../includes/DatabaseFunctions.php';

        if (!empty($_POST['users']) && !empty($_POST['module'])) {
            insertQuestion($pdo, ($_POST['title']), $_POST['users'], $_POST['module'], ($_FILES['fileToUpload']['name']));
            include '../includes/uploadfile.php';
            header('location: question.php');
            exit();
        } else {
            throw new Exception('User or Module not selected.');
        }
    } catch (Exception $e) {
        $title = 'Error';
        $output = 'Validation error: ' . $e->getMessage();
    } catch (PDOException $e) {
        $title = 'Database error';
        $output = 'Database error: ' . $e->getMessage();
    }
} else {
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunctions.php';
    $title = 'Add a new question';
    $user = allUser($pdo);
    $module = allModule($pdo);
    $question = ['image' => ''];
    ob_start();
    include 'template/addquestion.html.php';
    $output = ob_get_clean();
}
include 'template/admin_layout.html.php';
