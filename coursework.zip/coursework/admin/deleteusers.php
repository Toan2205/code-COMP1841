<?php 
try{
   include '../includes/DatabaseConnection.php';
   include '../includes/DatabaseFunctions.php';
    deleteUser($pdo, $_POST['id']);
    header ('location: users.php');
}catch (PDOException $e){
        $title = 'An error has occured';
        $output = 'Database error:'. $e->getMessage();
    }
include 'template/layout.html.php';
?>