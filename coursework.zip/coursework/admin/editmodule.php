
<?php 
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
try{
    if(isset($_POST['modulename'])){
        updateModule($pdo, $_POST['module'], $_POST['modulename']);
        header('location: module.php');
   }else {
    $module = getModule($pdo, $_GET['id']);
    $title = 'Edit module';

    ob_start();
    include 'template/editmodule.html.php';
    $output = ob_get_clean();
    }
}catch(PDOException $e){
    $title = 'error has occured';
    $output = 'Error editing question: '. $e->getMessage();
}
include 'template/layout.html.php';
