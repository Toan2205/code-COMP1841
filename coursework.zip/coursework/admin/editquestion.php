<?php 
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';

try {
    if (isset($_POST['title'])) {
        if (!empty($_POST['users']) && !empty($_POST['module'])) {
            updateQuestion($pdo,$_POST['questionid'], trim($_POST['title']),$_POST['users'],$_POST['module'],trim($_POST['image']));
            header('location: question.php');
            exit();
        } else {
            throw new Exception('User and Module must be selected.');
        }
    } else {
        $user = allUser($pdo);
        $module = allModule($pdo);
        $question = getQuestion($pdo, $_GET['id']);
        $title = 'Edit question';

        ob_start();
        include 'template/editquestion.html.php';
        $output = ob_get_clean();
    }
} catch (Exception $e) {
    $title = 'An error has occurred';
    $output = 'Error editing question: ' . $e->getMessage();
} catch (PDOException $e) {
    $title = 'Database error';
    $output = 'Database error: ' . $e->getMessage();
}

include 'template/admin_layout.html.php';
