
<?php 
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
try{
    if(isset($_POST['title'])){
        updateQuestion($pdo, $_POST['questionid'], $_POST['title']);
        header('location: question.php');
   }else {
    $user = allUser($pdo);
    $module = allModule($pdo);
    $question = getQuestion($pdo, $_GET['id']);
    $title = 'Edit question';

    ob_start();
    include 'template/editquestion.html.php';
    $output = ob_get_clean();
    }
}catch(PDOException $e){
    $title = 'error has occured';
    $output = 'Error editing question: '. $e->getMessage();
}
include 'template/layout.html.php';
