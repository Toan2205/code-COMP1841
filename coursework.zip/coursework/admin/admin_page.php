<?php

$title = 'Do you have any question?';
ob_start();
include 'template/home.html.php';
$output = ob_get_clean();
include 'template/admin_layout.html.php';
?>
