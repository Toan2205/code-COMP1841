<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunctions.php';
session_start();

$title = "Message History";


$role = $_SESSION['role'] ?? null;
$user_id = $_SESSION['user_id'] ?? null;


if (!$role || !$user_id) {
    header('Location: ../login/index.php');
    exit();
}

if ($role === 'admin') {
    $messages = getMessagesForAdmin($pdo);  
} else {
    $messages = getMessagesForUser($pdo, $user_id); 
}


ob_start();
include 'template/message_history.html.php';
$output = ob_get_clean();

include 'template/admin_layout.html.php';

