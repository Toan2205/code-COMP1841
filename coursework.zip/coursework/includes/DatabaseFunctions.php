<?php
function totalQuestion($pdo){
    $query = query ($pdo,'SELECT COUNT(*) FROM question');
    $row = $query->fetch();
    return $row[0];
}
function totalUser($pdo){
    $query = query( $pdo,'SELECT COUNT(*) FROM users');
    $query->execute();
    $row = $query->fetch();
    return $row[0];
}
function totalModule($pdo){
    $query = query($pdo,'SELECT COUNT(*) FROM module');
    $query->execute();
    $row = $query->fetch();
    return $row[0];
}   
function query($pdo, $sql, $parameters = []){
    $query = $pdo->prepare($sql);
    $query->execute($parameters);
    return $query;
}
function getQuestion($pdo, $id){
    $parameters = [':id' => $id];
    $query = query($pdo, 'SELECT * FROM question WHERE id = :id', $parameters);
    return $query->fetch();
}
function getUser($pdo, $id){
    $parameters = [':id' => $id];
    $query = query($pdo, 'SELECT * FROM users WHERE id = :id', $parameters);
    return $query->fetch();
}
function getModule($pdo, $id){
    $parameters = [':id' => $id];
    $query = query($pdo, 'SELECT * FROM module WHERE id = :id', $parameters);
    return $query->fetch();
}
function updateQuestion($pdo, $questionId, $title, $userid, $moduleid, $image){ 
    $query = 'UPDATE question SET title = :title, userid = :userid, moduleid = :moduleid, image = :image WHERE id = :id';
    $parameters = [':title' => $title,':userid' => $userid,':moduleid' => $moduleid,':id' => $questionId, ':image' => $image];
    query($pdo, $query, $parameters);
}

function updateUser($pdo, $userId, $email, $username){
    $query = 'UPDATE users SET  username =:username, email = :email WHERE id = :id';
    $parameters = [ ':id' => $userId, ':username' => $username, ':email' => $email];    
    query($pdo, $query, $parameters);
}   
function updateModule($pdo, $moduleId, $modulename){
    $query = 'UPDATE module SET  modulename = :modulename WHERE id = :id';
    $parameters = [ ':id' => $moduleId, ':modulename' => $modulename];
    query($pdo, $query, $parameters);
}
function deleteQuestion($pdo, $id){
    $parameters = [':id' => $id];
    query($pdo, 'DELETE FROM question WHERE id = :id', $parameters);
}

function deleteUser($pdo, $id){
    $parameters = [':id' => $id];
    query($pdo, 'DELETE FROM users WHERE id = :id', $parameters);
}
function deleteModule($pdo, $id){
    $parameters = [':id' => $id];
    query($pdo, 'DELETE FROM module WHERE id = :id', $parameters);
}
function deleteMessage($pdo, $id){
    $parameters = [':id' => $id];
    query($pdo, 'DELETE FROM message WHERE id = :id', $parameters);
}
function insertQuestion($pdo, $title, $userid, $moduleid, $fileToUpload){
    $query = 'INSERT INTO question (title, questiondate, `image`, userid, moduleid)
              VALUES (:title, CURDATE(), :fileToUpload, :userid, :moduleid)';
    $parameters = [':title' => $title,':fileToUpload' => $fileToUpload,':userid' => $userid,':moduleid' => $moduleid];
    query($pdo, $query, $parameters);
}

function insertUser($pdo, $username, $email){
    $query = 'INSERT INTO users (username, email) 
              VALUES (:username, :email)';
    $parameters = [':username' => $username, ':email' => $email];
    query($pdo, $query, $parameters);
}
function insertModule($pdo, $modulename){
    $query ='INSERT INTO module (modulename)
    VALUES (:modulename)';
    $parameters = [':modulename' => $modulename];
    query($pdo, $query, $parameters);
}
function allUser($pdo){
    $user = query($pdo, 'SELECT * FROM users');
    return $user->fetchAll();
}
function allModule($pdo){
    $module = query($pdo, 'SELECT * FROM module');
    return $module->fetchAll();
}
function allQuestion($pdo){
    $questions = query($pdo, 'SELECT question.id, title, questiondate, `image`, username, email, modulename FROM question
    INNER JOIN users ON userid = users.id
    INNER JOIN module ON moduleid = module.id');
    return $questions->fetchAll();
}
function insertMessage($pdo, $sender_id, $receiver_id, $msg) {
    $sql = "INSERT INTO message (sender_id, receiver_id, message, sent_at)
            VALUES (:sender_id, :receiver_id, :message, NOW())";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':sender_id' => $sender_id,
        ':receiver_id' => $receiver_id,
        ':message' => $msg
    ]);
}

function getMessagesForAdmin($pdo) {
    $sql = "SELECT m.*, u1.email as sender_email, u2.email as receiver_email
            FROM message m
            JOIN users u1 ON m.sender_id = u1.id
            JOIN users u2 ON m.receiver_id = u2.id
            ORDER BY m.sent_at DESC";
    return $pdo->query($sql);
}

function getMessagesForUser($pdo, $uid) {
    $sql = "SELECT m.*, u1.email as sender_email, u2.email as receiver_email
            FROM message m
            JOIN users u1 ON m.sender_id = u1.id
            JOIN users u2 ON m.receiver_id = u2.id
            WHERE sender_id = :uid OR receiver_id = :uid
            ORDER BY m.sent_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':uid' => $uid]);
    return $stmt->fetchAll();
}
function getAllAdmins($pdo) {
    $stmt = $pdo->prepare("SELECT id, email FROM users WHERE role = 'admin'");
    $stmt->execute();
    return $stmt->fetchAll();
}

function getAllUsers($pdo) {
    $stmt = $pdo->prepare("SELECT id, email FROM users WHERE role = 'user'");
    $stmt->execute();
    return $stmt->fetchAll();
}

