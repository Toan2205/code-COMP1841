<?php
function totalQuestion($pdo){
    $query = query ($pdo,'SELECT COUNT(*) FROM question');
    $row = $query->fetch();
    return $row[0];
}
function totalUser($pdo){
    $query = query( $pdo,'SELECT COUNT(*) FROM users');
    $query->execute();
    $row = $query->fetch();
    return $row[0];
}
function totalModule($pdo){
    $query = query($pdo,'SELECT COUNT(*) FROM module');
    $query->execute();
    $row = $query->fetch();
    return $row[0];
}   
function query($pdo, $sql, $parameters = []){
    $query = $pdo->prepare($sql);
    $query->execute($parameters);
    return $query;
}
function getQuestion($pdo, $id){
    $parameters = [':id' => $id];
    $query = query($pdo, 'SELECT * FROM question WHERE id = :id', $parameters);
    return $query->fetch();
}
function getUser($pdo, $id){
    $parameters = [':id' => $id];
    $query = query($pdo, 'SELECT * FROM users WHERE id = :id', $parameters);
    return $query->fetch();
}
function getModule($pdo, $id){
    $parameters = [':id' => $id];
    $query = query($pdo, 'SELECT * FROM module WHERE id = :id', $parameters);
    return $query->fetch();
}
function updateQuestion($pdo, $questionId, $title){
    $query = 'UPDATE question GET title = :title, username =:username, modulename = :modulename WHERE id = :id';
    $parameters = [':title' => $title, ':id' => $questionId, ':username' => $username, ':modulename' => $modulename];
    query($pdo, $query, $parameters);
}
function updateUser($pdo, $userId, $title){
    $query = 'UPDATE users GET  username =:username WHERE id = :id';
    $parameters = [ ':id' => $userId, ':username' => $username];
    query($pdo, $query, $parameters);
}
function updateModule($pdo, $moduleId, $title){
    $query = 'UPDATE module GET  modulename = :modulename WHERE id = :id';
    $parameters = [ ':id' => $moduleId, ':modulename' => $modulename];
    query($pdo, $query, $parameters);
}
function deleteQuestion($pdo, $id){
    $parameters = [':id' => $id];
    query($pdo, 'DELETE FROM question WHERE id = :id', $parameters);
}

function deleteUser($pdo, $id){
    $parameters = [':id' => $id];
    query($pdo, 'DELETE FROM users WHERE id = :id', $parameters);
}
function deleteModule($pdo, $id){
    $parameters = [':id' => $id];
    query($pdo, 'DELETE FROM module WHERE id = :id', $parameters);
}
function insertQuestion($pdo, $title, $userid, $moduleid){
    $query ='INSERT INTO question (title, questiondate, userid, moduleid)
    VALUES (:title, CURDATE(), :userid, :moduleid)';
    $parameters = [':title' => $title, ':userid' => $userid, ':moduleid' => $moduleid];
    query($pdo, $query, $parameters);
}
function insertUser($pdo, $username, $email){
    $query = 'INSERT INTO users (username, email) 
              VALUES (:username, :email)';
    $parameters = [':username' => $username, ':email' => $email];
    query($pdo, $query, $parameters);
}
function insertModule($pdo, $modulename){
    $query ='INSERT INTO module (modulename)
    VALUES (:modulename)';
    $parameters = [':modulename' => $modulename];
    query($pdo, $query, $parameters);
}
function allUser($pdo){
    $user = query($pdo, 'SELECT * FROM users');
    return $user->fetchAll();
}
function allModule($pdo){
    $module = query($pdo, 'SELECT * FROM module');
    return $module->fetchAll();
}
function allQuestion($pdo){
    $questions = query($pdo, 'SELECT question.id, title, questiondate, `image`, username, email, modulename FROM question
    INNER JOIN users ON userid = users.id
    INNER JOIN module ON moduleid = module.id');
    return $questions->fetchAll();
}