<?php
$target_dir = "../uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

if (!empty($_FILES["fileToUpload"]["tmp_name"])) {
    
    if ($_FILES["fileToUpload"]["size"] > 5000000) {
        throw new Exception("File is too large (max 5MB).");
    }

    $allowedTypes = ["jpg", "jpeg", "png", "gif", "pdf"];
    if (!in_array($imageFileType, $allowedTypes)) {
        throw new Exception("Only JPG, JPEG, PNG, GIF & PDF files are allowed.");
    }

    if (file_exists($target_file)) {
        $target_file = $target_dir . time() . "_" . basename($_FILES["fileToUpload"]["name"]);
    }

    if (!move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        throw new Exception("Error while uploading the file.");
    }
}
